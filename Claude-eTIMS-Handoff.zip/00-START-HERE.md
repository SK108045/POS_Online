# Claude eTIMS Handoff — Start Here

Repository: SK108045/POS_Online (private)
Pinned source commit: 1139a045462fbc99b4f58aefe4f18e618e4f6f93
Commit message: fix(etims): resolve Vercel serverless routing 404 and bundle fast_engine into EtimsLocalWorker

## Goal
Review why invoice creation shows: Unexpected token 'T', "The page c" is not valid JSON.

## Architecture map
1. The deployed frontend is public/app.js plus public/etims-core.js and public/etims-integration.js.
2. The Vercel serverless API is api/index.js; Supabase client setup is api/supabase.js; queue schema is under supabase/migrations/.
3. Online flow: checkout/order payment -> Supabase etims_queue -> local Windows cloud worker -> queue result and fiscal fields -> POS receipt.
4. The cloud worker is windows/etims-helper/local_etims_worker.py. It polls Supabase/Postgres or Vercel worker endpoints and uses the local eTIMS engine.
5. There is a second, separate local-only path: capacitor/dev-server.js routes /api/etims/* to capacitor/etims-windows.js, which proxies to the Windows helper on 127.0.0.1:17383. That path only works from a browser on the same Windows PC.

## Please inspect
- Verify production /api/etims/health and /api/etims/jobs really reach api/index.js and return JSON on success and failure.
- Look for Vercel routing/rewrite mismatches that could return a plain-text/HTML page-not-found response instead of JSON. The pinned commit's message indicates a routing fix, so check whether the deployment contains it.
- Trace order/payment -> queue insert -> worker polling -> result update -> frontend poll/receipt, and check the shop_id and job_hash values agree.
- Check worker environment/configuration and whether the Windows worker is genuinely running; do not trust a hard-coded worker_ready response.
- Determine which of the two paths should be used in the deployed Vercel product, and identify any mixing of local-helper and cloud-worker endpoint contracts.
- Do not issue, retry, or duplicate a KRA invoice; do not run migrations or change eTIMS records during diagnosis. Give a read-only diagnosis and safe tests first.

## Scope and redactions
This is a compact review bundle, not a runnable app. It omits binaries, DLLs, screenshots, databases, QR/PDF samples, credentials files, dependencies and unrelated product assets. A hard-coded PostgreSQL connection string in local_etims_worker.py has been redacted in this copy. Do not reinsert it; use environment variables.